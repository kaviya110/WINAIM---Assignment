package com.fita.cmr.pojo;

public class contactentity {

}
