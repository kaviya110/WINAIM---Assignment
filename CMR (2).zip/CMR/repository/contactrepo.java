


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fita.cmr.pojo.contactentity;

@Repository
public interface contactrepo extends JpaRepository<contactentity, Long> {
}
