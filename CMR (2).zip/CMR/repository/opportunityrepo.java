package com.fita.cmr.repository;



import com.fita.cmr.pojo.opportunityentity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface opportunityrepo extends JpaRepository<opportunityentity, Long> {
}
