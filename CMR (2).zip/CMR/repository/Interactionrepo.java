package com.fita.cmr.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.fita.cmr.pojo.Interactionentity;
@Repository
public interface Interactionrepo extends JpaRepository<Interactionentity, Long> {
}
