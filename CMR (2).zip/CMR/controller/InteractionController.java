package com.fita.cmr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fita.cmr.service.Interactionservice;
import com.fita.cmr.pojo.Interactionentity;

import java.util.List;

@RestController
@RequestMapping("/api/interactions")
public class InteractionController {

    @Autowired
    private Interactionservice interactionService;

    @GetMapping
    public List<Interactionentity> getAllInteractions() {
        return Interactionservice.getAllInteractions();
    }

    @PostMapping
    public Interactionentity addInteraction(@RequestBody Interactionentity interaction) {
        return interactionService.addInteraction(interaction);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInteraction(@PathVariable Long id) {
        interactionService.deleteInteractionentity(id);
        return ResponseEntity.ok().build();
    }
}

