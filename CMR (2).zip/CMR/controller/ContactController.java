package com.fita.cmr.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fita.cmr.pojo.contactentity;
import com.fita.cmr.service.contactservice;

import java.util.List;

@RestController
@RequestMapping("/api/contacts")
public class ContactController {

    @Autowired
    private contactservice contactService;

    @GetMapping
    public List<contactentity> getAllContacts() {
        return contactservice.getAllContacts();
    }

    @PostMapping
    public contactentity addContact(@RequestBody contactentity contact) {
        return contactservice.addContact(contact);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteContact(@PathVariable Long id) {
        contactService.deleteContact(id);
        return ResponseEntity.ok().build();
    }
}



