package com.fita.cmr.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fita.cmr.pojo.customerentity;
import com.fita.cmr.service.customerservice;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private customerservice customerService;

    @GetMapping
    public List<customerentity> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    @GetMapping("/{id}")
    public ResponseEntity<customerentity> getCustomerById(@PathVariable Long id) {
        return customerService.getCustomerById(id)
                              .map(ResponseEntity::ok)
                              .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public customerentity addcustomerentity(@RequestBody customerentity customer) {
        return customerservice.addcustomerentity(customer);
    }

    @PutMapping("/{id}")
    public ResponseEntity<customerentity> updateCustomer(@PathVariable Long id, @RequestBody customerentity customer) {
        customerentity updatedCustomer = customerService.updateCustomer(id, customer);
        if (updatedCustomer != null) {
            return ResponseEntity.ok(updatedCustomer);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.ok().build();
    }
}



