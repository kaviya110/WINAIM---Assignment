package com.fita.cmr.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fita.cmr.pojo.opportunityentity;
import com.fita.cmr.service.opportunityservice;

import java.util.List;

@RestController
@RequestMapping("/api/opportunities")
public class OpportunityController {

    @Autowired
    private opportunityservice opportunityservice;

    @GetMapping
    public List<opportunityentity> getAllOpportunities() {
        return opportunityservice.getAllOpportunities();
    }

    @PostMapping
    public Opportunity addOpportunity(@RequestBody opportunityentity opportunity) {
        return opportunityservice.addopportunity(opportunity);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOpportunity(@PathVariable Long id) {
        opportunityservice.deleteOpportunity(id);
        return ResponseEntity.ok().build();
    }
}



