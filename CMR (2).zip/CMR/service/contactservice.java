package com.fita.cmr.service;
	
import com.fita.cmr.pojo.contactentity;

import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import java.util.List;

	@Service
	public class contactservice {

	    @Autowired
	    private contactentity contactRepository;

	    public List<contactentity> getAllContacts() {
	        return contactRepository.findAll();
	    }

	    public Contact addContact(Contact contact) {
	        return contactRepository.save(contact);
	    }

	    public void deleteContact(Long id) {
	        contactRepository.deleteById(id);
	    }
	}

}
