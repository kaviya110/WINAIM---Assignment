package com.fita.cmr.service;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import com.fita.cmr.pojo.Interactionentity;
import com.fita.cmr.repository.Interactionrepo;

import java.util.List;

	@Service
	public class Interactionservice {

	    @Autowired
	    private Interactionrepo interactionRepository;

	    public List<Interactionentity> getAllInteractions() {
	        return Interactionrepo.findAll();
	    }

	    public Interactionentity addInteraction(Interactionentity interaction) {
	        return Interactionrepo.save(interaction);
	    }

	    public void deleteInteractionentity(Long id) {
	    	interactionRepository.deleteById(id);
	    }
	}

}
