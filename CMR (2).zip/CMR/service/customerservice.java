package com.fita.cmr.service;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import com.fita.cmr.pojo.customerentity;
import com.fita.cmr.repository.customerrepo;

import java.util.List;
	import java.util.Optional;

	@Service
	public class customerservice {

	    @Autowired
	    private customerrepo customerRepository;
		private Object customerentity;

	    public List<customerentity> getAllCustomers() {
	        try {
				try {
					try {
						try {
							try {
								return customerrepo.findAll();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    public Optional<customerentity> getCustomerById(Long id) {
	        try {
				return customerrepo.findById(id);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    public customerentity addCustomer(customerentity customer) {
	        try {
				try {
					return customerrepo.save(customer);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }

	    public customerentity updateCustomer(Long id, customerentity customer) {
	        try {
				if (customerrepo.existsById(id)) {
				    customer.setId(id);
				    return customerrepo.save(customerentity);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        return null;
	    }

	    public void deleteCustomer(Long id) {
	        customerRepository.deleteById(id);
	    }
	}


