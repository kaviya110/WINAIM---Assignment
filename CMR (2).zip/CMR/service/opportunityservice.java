package com.fita.cmr.service;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

import com.fita.cmr.pojo.opportunityentity;
import com.fita.cmr.repository.opportunityrepo;

import java.util.List;

	@Service
	public class opportunityservice {

	    @Autowired
	    private opportunityrepo opportunityRepository;

	    public List<opportunityentity> getAllOpportunities() {
	        return opportunityrepo.findAll();
	    }

	    public opportunityentity addOpportunity(opportunityrepo opportunity) {
	        return opportunityrepo.save(opportunity);
	    }

	    public void deleteOpportunity(Long id) {
	    	opportunityrepo.deleteById(id);
	    }
	}

}
