spring.datasource.url=jdbc:mysql://localhost:3306/crm
spring.datasource.username=Kavii
spring.datasource.password=Kaviya02



for Update
spring.jpa.hibernate.ddl-auto=update
